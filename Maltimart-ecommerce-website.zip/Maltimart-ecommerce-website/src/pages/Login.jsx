// import React, { useState } from 'react';
// import Helmet from '../components/Helmet/Helmet';
// import { Container, Row, Col, Form, FormGroup } from "reactstrap";
// import { Link, useNavigate } from 'react-router-dom';
// import '../styles/login.css';
// import { signInWithEmailAndPassword } from 'firebase/auth';
// import { auth } from '../firebase.config';
// import { toast } from 'react-toastify';


// const Login = () => {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [loading, setLoading] = useState(false);
//   const navigate = useNavigate();

//   const signIn = async (e) => {
//     e.preventDefault()
//     setLoading(true)

//     try {
//       const userCredential = await signInWithEmailAndPassword(auth, email, password)

//       const user = userCredential.user
//       console.log(user);
//       setLoading(false);
//       toast.success("Successfully logged in ");
//       navigate('/checkout');

//     } catch (error) {
//       setLoading(false)
//       toast.error(error.message);


//     }
//   }





//   return (
//     <Helmet title='Login'>
//       <section>
//         <Container>


//           <Row>

//             {loading ? (
//               <Col lg='12' className='text-center'>
//                 <h5 className='fw-bold'>Loading...</h5>
//               </Col>
//             ) : (
//               <Col lg='6' className='m-auto text-center'>
//                 <h3 className='fw-bold mb-4'>Login</h3>

//                 <Form className='auth__form' onSubmit={signIn}>
//                   <FormGroup className='form__group'>
//                     <input type="email" placeholder='Enter your email' value={email} onChange={e => setEmail(e.target.value)} />
//                   </FormGroup>

//                   <FormGroup className='form__group'>
//                     <input type="passwprd" placeholder='Enter your password' value={password} onChange={e => setPassword(e.target.value)} />
//                   </FormGroup>

//                   <button type='submit' className="buy__btn auth__btn">Login</button>
//                   <p>Don't have an account? {""} <Link to='/signup'>Create an account</Link></p>





//                 </Form>


//               </Col>)

//             }


//           </Row>


//         </Container>


//       </section>



//     </Helmet>
//   )
// }

// export default Login

import React from 'react';
import Helmet from '../components/Helmet/Helmet';
import { Container, Row, Col, Form, FormGroup } from "reactstrap";
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import '../styles/login.css';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase.config';
import { toast } from 'react-toastify';

const Login = () => {
  const [loading, setLoading] = React.useState(false);
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email('Invalid email address')
        .required('Email is required'),
      password: Yup.string()
        .min(6, 'Password must be at least 6 characters')
        .required('Password is required'),
    }),
    onSubmit: async (values) => {
      setLoading(true);

      try {
        const userCredential = await signInWithEmailAndPassword(auth, values.email, values.password);
        const user = userCredential.user;
        console.log(user);
        setLoading(false);
        toast.success("Successfully logged in");
        navigate('/checkout');
      } catch (error) {
        setLoading(false);
        toast.error(error.message);
      }
    },
  });

  return (
    <Helmet title='Login'>
      <section>
        <Container>
          <Row>
            {loading ? (
              <Col lg='12' className='text-center'>
                <h5 className='fw-bold'>Loading...</h5>
              </Col>
            ) : (
              <Col lg='6' className='m-auto text-center'>
                <h3 className='fw-bold mb-4'>Login</h3>
                <Form className='auth__form' onSubmit={formik.handleSubmit}>
                  <FormGroup className='form__group'>
                    <input
                      type="email"
                      name="email"
                      placeholder='Enter your email'
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.email && formik.errors.email ? (
                      <div className="error">{formik.errors.email}</div>
                    ) : null}
                  </FormGroup>
                  <FormGroup className='form__group'>
                    <input
                      type="password"
                      name="password"
                      placeholder='Enter your password'
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.password && formik.errors.password ? (
                      <div className="error">{formik.errors.password}</div>
                    ) : null}
                  </FormGroup>
                  <button type='submit' className="buy__btn auth__btn">Login</button>
                  <p>Don't have an account? <Link to='/signup'>Create an account</Link></p>
                </Form>
              </Col>
            )}
          </Row>
        </Container>
      </section>
    </Helmet>
  );
}

export default Login;
