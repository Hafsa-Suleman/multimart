

import React from 'react';
import Helmet from '../components/Helmet/Helmet';
import { Container, Row, Col, Form, FormGroup } from "reactstrap";
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import '../styles/login.css';
import { getAuth, createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { setDoc, doc } from 'firebase/firestore';
import { toast } from 'react-toastify';
import { auth, storage, db } from '../firebase.config';

const Signup = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState(false);

  const formik = useFormik({
    initialValues: {
      username: '',
      email: '',
      password: '',
      file: null,
    },
    validationSchema: Yup.object({
      username: Yup.string()
        .required('Username is required'),
      email: Yup.string()
        .email('Invalid email address')
        .required('Email is required'),
      password: Yup.string()
        .min(6, 'Password must be at least 6 characters')
        .required('Password is required'),
      file: Yup.mixed().required('A file is required'),
    }),
    onSubmit: async (values) => {
      setLoading(true);

      try {
        const userCredential = await createUserWithEmailAndPassword(auth, values.email, values.password);
        const user = userCredential.user;

        const storageRef = ref(storage, `images/${Date.now() + values.username}`);
        const uploadTask = uploadBytesResumable(storageRef, values.file);

        uploadTask.on('state_changed',
          (snapshot) => {
            // Optional: Handle upload progress
          },
          (error) => {
            toast.error(error.message);
            setLoading(false);
          },
          async () => {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);

            // Update user profile
            await updateProfile(user, {
              displayName: values.username,
              photoURL: downloadURL,
            });

            // Store user data in Firestore
            await setDoc(doc(db, 'users', user.uid), {
              uid: user.uid,
              displayName: values.username,
              email: values.email,
              photoURL: downloadURL,
            });

            setLoading(false);
            toast.success('Account created');
            navigate('/login'); // Redirect to the login page
          }
        );
      } catch (error) {
        toast.error('Something went wrong: ' + error.message);
        setLoading(false);
      }
    },
  });

  return (
    <Helmet title='Signup'>
      <section>
        <Container>
          <Row>
            {loading ? (
              <Col lg='12' className='text-center'>
                <h5 className='fw-bold'>Loading...</h5>
              </Col>
            ) : (
              <Col lg='6' className='m-auto text-center'>
                <h3 className='fw-bold mb-4'>Signup</h3>
                <Form className='auth__form' onSubmit={formik.handleSubmit}>
                  <FormGroup className='form__group'>
                    <input
                      type="text"
                      name="username"
                      placeholder='Username'
                      value={formik.values.username}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.username && formik.errors.username ? (
                      <div className="error">{formik.errors.username}</div>
                    ) : null}
                  </FormGroup>
                  <FormGroup className='form__group'>
                    <input
                      type="email"
                      name="email"
                      placeholder='Enter your email'
                      value={formik.values.email}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.email && formik.errors.email ? (
                      <div className="error">{formik.errors.email}</div>
                    ) : null}
                  </FormGroup>
                  <FormGroup className='form__group'>
                    <input
                      type="password"
                      name="password"
                      placeholder='Enter your password'
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.password && formik.errors.password ? (
                      <div className="error">{formik.errors.password}</div>
                    ) : null}
                  </FormGroup>
                  <FormGroup className='form__group'>
                    <input
                      type="file"
                      name="file"
                      onChange={(event) => {
                        formik.setFieldValue("file", event.currentTarget.files[0]);
                      }}
                      onBlur={formik.handleBlur}
                    />
                    {formik.touched.file && formik.errors.file ? (
                      <div className="error">{formik.errors.file}</div>
                    ) : null}
                  </FormGroup>
                  <button type='submit' className="buy__btn auth__btn">Create an Account</button>
                  <p>Already have an account? <Link to='/login'>Login</Link></p>
                </Form>
              </Col>
            )}
          </Row>
        </Container>
      </section>
    </Helmet>
  );
};

export default Signup;
