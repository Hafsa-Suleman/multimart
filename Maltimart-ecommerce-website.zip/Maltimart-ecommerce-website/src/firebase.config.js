
// import { initializeApp } from "firebase/app";
// import { getAuth } from "firebase/auth";
// import { getFirestore } from "firebase/firestore";
// import { getStorage } from "firebase/storage";


// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyAh-N0AsOcW3bCcm_HnhLfBOroOCL65hf0",
//   authDomain: "maltimart-433a0.firebaseapp.com",
//   projectId: "maltimart-433a0",
//   storageBucket: "maltimart-433a0.appspot.com",
//   messagingSenderId: "1059395752816",
//   appId: "1:1059395752816:web:57d36365153118875235b5"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// export const auth = getAuth(app);
// export const db = getFirestore(app);
//  export const storage = getStorage(app);
// export default app;

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAh-N0AsOcW3bCcm_HnhLfBOroOCL65hf0",
  authDomain: "maltimart-433a0.firebaseapp.com",
  projectId: "maltimart-433a0",
  storageBucket: "maltimart-433a0.appspot.com",
  messagingSenderId: "1059395752816",
  appId: "1:1059395752816:web:57d36365153118875235b5"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
