# MultiMart

MultiMart is a modern e-commerce platform built using React, Redux Toolkit, Formik, Yup, and Firebase. This project includes a fully responsive design and a variety of features including product listings, detailed product pages, a shopping cart, multi-step checkout, and an admin panel.

## Features

- **User Authentication:** Sign up and log in using Formik and Yup for form handling and validation.
- **Product Listings:** Browse and search for products with detailed product pages.
- **Shopping Cart:** Add, remove, and manage products in your cart.
- **Multi-Step Checkout:** Seamlessly complete your purchase with a step-by-step checkout process.
- **Admin Panel:** Manage products and user accounts from an admin interface.
- **Responsive Design:** Ensures a clean and modern look on all devices.

## Technologies Used

- **React:** For building user interfaces.
- **Redux Toolkit:** For state management.
- **Formik:** For handling forms.
- **Yup:** For form validation.
- **Firebase:** For backend services including authentication and database.
- **Custom CSS:** For styling and responsiveness.

## Installation



1. **Navigate to the Project Directory:**

    ```bash
    cd multimart
    ```

2. **Install Dependencies:**

    ```bash
    npm install
    ```

3. **Set Up Firebase:**

    - Create a Firebase project in the [Firebase Console](https://console.firebase.google.com/).
    - Add a web app to your Firebase project.
    - Copy your Firebase configuration and use it in your project as follows:

    Create a `firebase.js` file in the `src` directory of your React project and add your Firebase configuration directly:

    ```javascript
    // src/firebase.js
    import { initializeApp } from 'firebase/app';
    import { getAuth } from 'firebase/auth';
    import { getFirestore } from 'firebase/firestore';

    const firebaseConfig = {
      apiKey: 'your-api-key',
      authDomain: 'your-auth-domain',
      projectId: 'your-project-id',
      storageBucket: 'your-storage-bucket',
      messagingSenderId: 'your-messaging-sender-id',
      appId: 'your-app-id'
    };

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);
    const db = getFirestore(app);

    export { auth, db };
    ```

4. **Run the Development Server:**

    ```bash
    npm start
    ```

    Navigate to `http://localhost:3000` in your browser to view the application.

## Usage

- **Sign Up / Log In:** Use the authentication forms to create an account or log in.
- **Browse Products:** Navigate through product listings and view details.
- **Manage Cart:** Add or remove products from the cart.
- **Checkout:** Complete your purchase through the multi-step checkout process.
- **Admin Panel:** Access the admin panel to manage products and user accounts



## Contact

For any questions or issues, please contact [hafsasuleman72@gmail.com]

---

